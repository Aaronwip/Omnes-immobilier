<?php
session_start();

if (!isset($_SESSION['id_user'])) {
    header("Location: votrecompte.php");
    exit();
}

$mysqli = new mysqli("localhost", "root", "", "omnes_immobilier");
if ($mysqli->connect_error) {
    die("Erreur de connexion : " . $mysqli->connect_error);
}

$id = $_SESSION['id_user'];
$result = $mysqli->query("SELECT role FROM users WHERE id_user = $id");
$user = $result->fetch_assoc();
if (!$user || $user['role'] !== 'admin') {
    die("Accès refusé.");
}

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    die("ID agent invalide.");
}
$id_agent = intval($_GET['id']);

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $prenom = $mysqli->real_escape_string($_POST['prenom']);
    $nom = $mysqli->real_escape_string($_POST['nom']);
    $email = $mysqli->real_escape_string($_POST['email']);
    $tel = $mysqli->real_escape_string($_POST['telephone']);
    $specialite = intval($_POST['specialite_id']);

    $photo_path = $_POST['ancienne_photo'];
    if (isset($_FILES['photo']) && $_FILES['photo']['error'] === 0) {
        $filename = basename($_FILES['photo']['name']);
        $destination = "Photos_agents/" . $filename;
        move_uploaded_file($_FILES['photo']['tmp_name'], $destination);
        $photo_path = $destination;
    }

    $cv_path = $_POST['ancien_cv'];
    if (isset($_FILES['cv']) && $_FILES['cv']['error'] === 0) {
        $filename = basename($_FILES['cv']['name']);
        $destination = "CV_agents/" . $filename;
        move_uploaded_file($_FILES['cv']['tmp_name'], $destination);
        $cv_path = $destination;
    }

    // MAJ de l’agent
    $stmt = $mysqli->prepare("UPDATE agents SET prenom = ?, nom = ?, email = ?, telephone = ?, photo = ?, cv = ?, specialite_id = ? WHERE id_agent = ?");
    $stmt->bind_param("ssssssii", $prenom, $nom, $email, $tel, $photo_path, $cv_path, $specialite, $id_agent);
    $stmt->execute();

    // Disponibilités : lundi à samedi
    $jours = ["lundi", "mardi", "mercredi", "jeudi", "vendredi", "samedi"];
    foreach ($jours as $jour) {
        $debut = $_POST["debut_$jour"];
        $fin = $_POST["fin_$jour"];

        if (!empty($debut) && !empty($fin) && strtotime($fin) > strtotime($debut)) {
        $check = $mysqli->query("SELECT COUNT(*) AS total FROM disponibilites WHERE agent_id = $id_agent AND jour = '$jour'");
            if ($check->num_rows > 0) {
                $stmt = $mysqli->prepare("UPDATE disponibilites SET heure_debut = ?, heure_fin = ? WHERE agent_id = ? AND jour = ?");
                $stmt->bind_param("ssis", $debut, $fin, $id_agent, $jour);
            } else {
                $stmt = $mysqli->prepare("INSERT INTO disponibilites (agent_id, jour, heure_debut, heure_fin) VALUES (?, ?, ?, ?)");
                $stmt->bind_param("isss", $id_agent, $jour, $debut, $fin);
            }
            $stmt->execute();
        }
    }

    header("Location: gestion_agents.php");
    exit();
}

$res = $mysqli->query("SELECT * FROM agents WHERE id_agent = $id_agent");
if (!$res || $res->num_rows !== 1) {
    die("Agent introuvable.");
}
$agent = $res->fetch_assoc();
$dispo = [];
$dq = $mysqli->query("SELECT * FROM disponibilites WHERE agent_id = $id_agent");
while ($d = $dq->fetch_assoc()) {
    $dispo[$d['jour']] = $d;
}
$specialites = $mysqli->query("SELECT id_specialite, nom FROM specialites");
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Modifier Agent</title>
    <link rel="stylesheet" href="style-header.css">
    <style>
        body { font-family: Arial; background: #f2f2f2; margin: 0; }
        .wrapper {
            max-width: 700px;
            margin: 40px auto;
            background: white;
            padding: 20px;
            border-radius: 10px;
        }
        h1 { text-align: center; }
        form label { display: block; margin-top: 15px; font-weight: bold; }
        input, select {
            width: 100%; padding: 10px; margin-top: 5px;
            border: 1px solid #ccc; border-radius: 5px;
        }
        .btn {
            background-color: #0B3D91;
            color: white;
            border: none;
            padding: 12px;
            margin-top: 20px;
            border-radius: 5px;
            cursor: pointer;
            width: 100%;
        }
        .dispo-block { margin-top: 20px; background: #f9f9f9; padding: 10px; border-radius: 6px; }
        .preview { margin-top: 10px; }
    </style>
</head>
<body>
<?php include 'header.php'; ?>

<div class="wrapper">
    <h1>Modifier l'agent <?= htmlspecialchars($agent['prenom']) ?></h1>

    <form method="post" enctype="multipart/form-data">
        <label>Prénom</label>
        <input type="text" name="prenom" value="<?= htmlspecialchars($agent['prenom']) ?>" required>

        <label>Nom</label>
        <input type="text" name="nom" value="<?= htmlspecialchars($agent['nom']) ?>" required>

        <label>Email</label>
        <input type="email" name="email" value="<?= htmlspecialchars($agent['email']) ?>" required>

        <label>Téléphone</label>
        <input type="text" name="telephone" value="<?= htmlspecialchars($agent['telephone']) ?>" required>

        <label>Spécialité</label>
        <select name="specialite_id">
            <?php while ($s = $specialites->fetch_assoc()): ?>
                <option value="<?= $s['id_specialite'] ?>" <?= $s['id_specialite'] == $agent['specialite_id'] ? 'selected' : '' ?>>
                    <?= htmlspecialchars($s['nom']) ?>
                </option>
            <?php endwhile; ?>
        </select>

        <label>Photo</label>
        <input type="file" name="photo" accept="image/*">
        <?php if ($agent['photo']): ?>
            <div class="preview"><img src="<?= htmlspecialchars($agent['photo']) ?>" alt="photo" height="80"></div>
        <?php endif; ?>
        <input type="hidden" name="ancienne_photo" value="<?= htmlspecialchars($agent['photo']) ?>">

        <label>CV</label>
        <input type="file" name="cv" accept=".pdf,.doc,.docx">
        <?php if ($agent['cv']): ?>
            <div class="preview"><a href="<?= htmlspecialchars($agent['cv']) ?>" target="_blank">Voir CV</a></div>
        <?php endif; ?>
        <input type="hidden" name="ancien_cv" value="<?= htmlspecialchars($agent['cv']) ?>">

        <h2>Disponibilités (lundi à samedi)</h2>
        <?php foreach (["lundi", "mardi", "mercredi", "jeudi", "vendredi", "samedi"] as $jour): ?>
            <div class="dispo-block">
                <label><?= ucfirst($jour) ?> - Heure de début</label>
                <input type="time" name="debut_<?= $jour ?>" value="<?= $dispo[$jour]['heure_debut'] ?? '' ?>">

                <label><?= ucfirst($jour) ?> - Heure de fin</label>
                <input type="time" name="fin_<?= $jour ?>" value="<?= $dispo[$jour]['heure_fin'] ?? '' ?>">
            </div>
        <?php endforeach; ?>

        <button class="btn" type="submit">Enregistrer les modifications</button>
    </form>
</div>
</body>
</html>
