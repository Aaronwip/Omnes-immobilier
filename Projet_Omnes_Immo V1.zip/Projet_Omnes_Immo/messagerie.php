<script>
function openForm(chatId) {
    document.querySelectorAll('.form-popup').forEach(el => el.style.display = 'none');
    document.getElementById(chatId).style.display = "block";
}

function closeForm(chatId) {
    document.getElementById(chatId).style.display = "none";
}

function sendMessage(event, chatId) {
    event.preventDefault();
    const form = event.target;
    form.querySelector('.confirmation').style.display = 'block';
    form.msg.value = '';
    return false;
}
</script>
